﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("GoldFishProject")]
[assembly: AssemblyDescription("by Davidwu 2008/9")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("cnpopsoft.com")]
[assembly: AssemblyProduct("GoldFishProject")]
[assembly: AssemblyCopyright("Copyright (C)  2008")]
[assembly: AssemblyTrademark("cnpopsoft.com")]
[assembly: AssemblyCulture("")]

[assembly: ComVisible(false)]

[assembly: Guid("d3a68b9e-2126-4ffd-8567-16b49725bf40")]

[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]
